import React from "react";
import IdealStockChart from "./IdealStockChart";

export default function IdealStockCenter(){
    return(
        <div className="card ideal-center-card">
            <IdealStockChart/>
        </div>
    )
}