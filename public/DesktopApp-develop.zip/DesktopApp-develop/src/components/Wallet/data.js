const walletData = [
  {
    date: "12-02-2020",
    time: "09:30AM",
    farmerUIN: "12235",
    amount: 12235,
  },
  {
    date: "10-02-2020",
    time: "09:30AM",
    farmerUIN: "12342",
    amount: 12342,
  },
  {
    date: "08-02-2020",
    time: "09:30AM",
    farmerUIN: "53312",
    amount: 53312,
  },
  {
    date: "05-02-2020",
    time: "09:30AM",
    farmerUIN: "12454",
    amount: 12454,
  },
  {
    date: "01-02-2020",
    time: "09:30AM",
    farmerUIN: "32112",
    amount: 32112,
  },
  {
    date: "12-02-2020",
    time: "09:30AM",
    farmerUIN: "12235",
    amount: 12235,
  },
  {
    date: "10-02-2020",
    time: "09:30AM",
    farmerUIN: "12342",
    amount: 12342,
  },
  {
    date: "08-02-2020",
    time: "09:30AM",
    farmerUIN: "53312",
    amount: 53312,
  },
  {
    date: "05-02-2020",
    time: "09:30AM",
    farmerUIN: "12454",
    amount: 12454,
  },
  {
    date: "01-02-2020",
    time: "09:30AM",
    farmerUIN: "32112",
    amount: 32112,
  },
  {
    date: "12-02-2020",
    time: "09:30AM",
    farmerUIN: "12235",
    amount: 12235,
  },
  {
    date: "10-02-2020",
    time: "09:30AM",
    farmerUIN: "12342",
    amount: 12342,
  },
  {
    date: "08-02-2020",
    time: "09:30AM",
    farmerUIN: "53312",
    amount: 53312,
  },
  {
    date: "05-02-2020",
    time: "09:30AM",
    farmerUIN: "12454",
    amount: 12454,
  },
  {
    date: "01-02-2020",
    time: "09:30AM",
    farmerUIN: "32112",
    amount: 32112,
  },
];

export default walletData;
