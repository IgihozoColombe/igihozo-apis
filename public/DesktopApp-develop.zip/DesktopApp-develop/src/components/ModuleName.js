import React from 'react'


function ModuleName() {
  return (
    <div>
      <h2>Create your component in similar way</h2>
    </div>
  )
}

export default ModuleName