import React from "react";

const History = () => (
  <div className="container">
    <h2>History</h2>
  </div>
);

export default History;
